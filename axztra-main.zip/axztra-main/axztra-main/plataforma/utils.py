from datetime import datetime
from .models import Solicitud, HistorialSolicitud

class CalculadorEstimacion:
    PRECIOS_BASE = {
        'Basica': 300000,
        'Media': 600000,
        'Alta': 1000000,
    }
    
    COSTOS_EXTRA = {
        'ecommerce': 300000,
        'formulario': 100000,
        'galeria': 80000,
        'blog': 150000,
        'login': 100000,
        'integracion_pago': 200000,
    }
    
    COSTO_POR_PAGINA = 50000
    
    @staticmethod
    def calcular(requerimientos):
        desglose = {}
        precio_base = CalculadorEstimacion.PRECIOS_BASE.get(requerimientos.complejidad, 600000)
        desglose['Precio base'] = precio_base
        total = precio_base
        
        if requerimientos.num_paginas > 1:
            costo_paginas = (requerimientos.num_paginas - 1) * CalculadorEstimacion.COSTO_POR_PAGINA
            desglose['Páginas adicionales'] = costo_paginas
            total += costo_paginas
        
        if requerimientos.tiene_ecommerce:
            desglose['E-commerce'] = CalculadorEstimacion.COSTOS_EXTRA['ecommerce']
            total += CalculadorEstimacion.COSTOS_EXTRA['ecommerce']
        
        if requerimientos.tiene_formulario:
            desglose['Formularios'] = CalculadorEstimacion.COSTOS_EXTRA['formulario']
            total += CalculadorEstimacion.COSTOS_EXTRA['formulario']
        
        if requerimientos.tiene_galeria:
            desglose['Galería'] = CalculadorEstimacion.COSTOS_EXTRA['galeria']
            total += CalculadorEstimacion.COSTOS_EXTRA['galeria']
        
        if requerimientos.tiene_blog:
            desglose['Blog'] = CalculadorEstimacion.COSTOS_EXTRA['blog']
            total += CalculadorEstimacion.COSTOS_EXTRA['blog']
        
        if requerimientos.tiene_login:
            desglose['Sistema de login'] = CalculadorEstimacion.COSTOS_EXTRA['login']
            total += CalculadorEstimacion.COSTOS_EXTRA['login']
        
        if requerimientos.tiene_integracion_pago:
            desglose['Pasarela de pagos'] = CalculadorEstimacion.COSTOS_EXTRA['integracion_pago']
            total += CalculadorEstimacion.COSTOS_EXTRA['integracion_pago']
        
        return {
            'total': total,
            'desglose': desglose,
            'es_referencial': True
        }

class GestorSolicitudes:
    @staticmethod
    def generar_numero():
        fecha = datetime.now().strftime('%Y%m%d')
        contador = Solicitud.objects.count() + 1
        return f"SOL-{fecha}-{contador:04d}"
    
    @staticmethod
    def cambiar_estado(solicitud, nuevo_estado, comentario="", usuario=None):
        estado_anterior = solicitud.estado_actual
        solicitud.estado_actual = nuevo_estado
        solicitud.save()
        
        HistorialSolicitud.objects.create(
            solicitud=solicitud,
            estado_anterior=estado_anterior,
            estado_nuevo=nuevo_estado,
            comentario=comentario,
            usuario=usuario
        )

class AsistenteIA:
    RESPUESTAS = {
        'precio': 'Los precios varían según la complejidad. Nuestra estimación te dará una referencia inicial. ¿Quieres solicitar una cotización?',
        'tiempo': 'Los proyectos básicos toman 2-3 semanas. Proyectos complejos pueden tardar 4-8 semanas.',
        'pago': 'Aceptamos transferencia bancaria, tarjeta de crédito y cheque. Los detalles se confirman en la cotización.',
        'soporte': 'Ofrecemos soporte técnico 24/7 para clientes con servicio activo.',
        'contacto': 'Puedes escribirnos a info@axztra.com o llamar al +56 9 1234 5678.',
        'mejoras': 'Sí, podemos mejorar tu página existente. ¿Qué cambios necesitas?',
        'mantenimiento': 'Ofrecemos mantenimiento mensual con actualizaciones y backups.',
        'hola': 'Hola! Soy el asistente de AXZTRA. ¿En qué puedo ayudarte?',
    }
    
    @staticmethod
    def procesar_pregunta(pregunta):
        pregunta_limpia = pregunta.lower().strip()
        
        for palabra_clave, respuesta in AsistenteIA.RESPUESTAS.items():
            if palabra_clave in pregunta_limpia:
                return respuesta
        
        return "No tengo una respuesta exacta. Contacta con nuestro equipo en info@axztra.com para más detalles."
