from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('catalogo/', views.catalogo, name='catalogo'),
    
    path('registro/', views.registro, name='registro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    path('crear-solicitud/paso1/', views.crear_solicitud_paso1, name='crear_solicitud_paso1'),
    path('crear-solicitud/paso2/', views.crear_solicitud_paso2, name='crear_solicitud_paso2'),
    path('solicitar-mejora/', views.solicitar_mejora, name='solicitar_mejora'),
    path('solicitar-soporte/', views.solicitar_soporte, name='solicitar_soporte'),
    
    path('solicitud/<int:id>/', views.ver_solicitud, name='ver_solicitud'),
    path('mis-solicitudes/', views.mis_solicitudes, name='mis_solicitudes'),
    
    path('chat/', views.chat_asistente, name='chat_asistente'),
    
    path('admin/panel/', views.panel_admin, name='panel_admin'),
    path('admin/cambiar-estado/<int:id>/', views.admin_cambiar_estado, name='admin_cambiar_estado'),
]
