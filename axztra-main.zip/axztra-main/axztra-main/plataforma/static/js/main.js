document.addEventListener('DOMContentLoaded', function () {

    // Animación de aparición al hacer scroll
    var revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && revealEls.length) {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });

        revealEls.forEach(function (el) { observer.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add('in-view'); });
    }

    // Selector interactivo de servicios
    var serviceItems = document.querySelectorAll('.service-item');
    if (serviceItems.length) {
        serviceItems.forEach(function (item) {
            item.addEventListener('click', function () {
                serviceItems.forEach(function (i) { i.classList.remove('active'); });
                item.classList.add('active');
            });
        });
    }

    // Carrusel de testimonios
    var track = document.querySelector('.testimonial-track');
    var prevBtn = document.querySelector('.carousel-btn.prev');
    var nextBtn = document.querySelector('.carousel-btn.next');
    if (track && prevBtn && nextBtn) {
        var scrollStep = function () {
            var card = track.querySelector('.testimonial-card');
            return card ? card.offsetWidth + 24 : 340;
        };
        nextBtn.addEventListener('click', function () {
            track.scrollBy({ left: scrollStep(), behavior: 'smooth' });
        });
        prevBtn.addEventListener('click', function () {
            track.scrollBy({ left: -scrollStep(), behavior: 'smooth' });
        });
    }

    // Formulario de contacto -> WhatsApp
    var contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var nombre = contactForm.querySelector('[name="nombre"]').value.trim();
            var servicio = contactForm.querySelector('[name="servicio"]');
            var servicioTexto = servicio.options[servicio.selectedIndex].text;
            var mensaje = contactForm.querySelector('[name="mensaje"]').value.trim();

            var texto = 'Hola, soy ' + nombre + '. Estoy interesado/a en: ' + servicioTexto;
            if (mensaje) { texto += '. ' + mensaje; }

            var numero = contactForm.getAttribute('data-whatsapp');
            var url = 'https://wa.me/' + numero + '?text=' + encodeURIComponent(texto);
            window.open(url, '_blank');
        });
    }
});
