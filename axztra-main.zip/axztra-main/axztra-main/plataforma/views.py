from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Servicio, Categoria, Solicitud, RequerimientoWeb, MensajeChat, Estimacion, HistorialSolicitud, PerfilCliente
from .forms import RegistroForm, LoginForm, RequerimientoWebForm, SolicitudCreacionForm, SolicitudMejoraForm, SolicitudSoporteForm, MensajeChatForm
from .utils import CalculadorEstimacion, GestorSolicitudes, AsistenteIA

def inicio(request):
    servicios = Servicio.objects.filter(activo=True)[:6]
    categorias = Categoria.objects.all()[:4]
    context = {
        'servicios': servicios,
        'categorias': categorias,
    }
    return render(request, 'plataforma/index.html', context)

def catalogo(request):
    servicios = Servicio.objects.filter(activo=True)
    categorias = Categoria.objects.all()
    categoria_id = request.GET.get('categoria')
    tipo = request.GET.get('tipo')
    
    if categoria_id:
        servicios = servicios.filter(categoria_id=categoria_id)
    if tipo:
        servicios = servicios.filter(tipo=tipo)
    
    context = {
        'servicios': servicios,
        'categorias': categorias,
        'categoria_activa': categoria_id,
    }
    return render(request, 'plataforma/catalogo.html', context)

def registro(request):
    if request.user.is_authenticated:
        return redirect('inicio')
    
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            user = form.save()
            PerfilCliente.objects.create(usuario=user)
            login(request, user)
            messages.success(request, 'Cuenta creada exitosamente!')
            return redirect('inicio')
    else:
        form = RegistroForm()
    
    return render(request, 'plataforma/auth/registro.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('inicio')
    
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            try:
                user = User.objects.get(email=email)
                user = authenticate(request, username=user.username, password=password)
                if user:
                    login(request, user)
                    messages.success(request, 'Sesión iniciada!')
                    return redirect('inicio')
                else:
                    messages.error(request, 'Contraseña incorrecta.')
            except User.DoesNotExist:
                messages.error(request, 'El correo no está registrado.')
    else:
        form = LoginForm()
    
    return render(request, 'plataforma/auth/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, 'Sesión cerrada.')
    return redirect('inicio')

@login_required
def crear_solicitud_paso1(request):
    if request.method == 'POST':
        form = RequerimientoWebForm(request.POST)
        if form.is_valid():
            req = form.save()
            estimacion_data = CalculadorEstimacion.calcular(req)
            request.session['req_id'] = req.id
            request.session['estimacion'] = estimacion_data
            return redirect('crear_solicitud_paso2')
    else:
        form = RequerimientoWebForm()
    
    return render(request, 'plataforma/solicitudes/crear_paso1.html', {'form': form})

@login_required
def crear_solicitud_paso2(request):
    req_id = request.session.get('req_id')
    estimacion = request.session.get('estimacion')
    
    if not req_id or not estimacion:
        messages.error(request, 'Sesión expirada.')
        return redirect('crear_solicitud_paso1')
    
    req = RequerimientoWeb.objects.get(id=req_id)
    
    if request.method == 'POST':
        form = SolicitudCreacionForm(request.POST)
        if form.is_valid():
            solicitud = form.save(commit=False)
            solicitud.cliente = request.user
            solicitud.tipo = 'Creacion'
            solicitud.numero = GestorSolicitudes.generar_numero()
            solicitud.requerimientos = req
            solicitud.estimacion_precio = estimacion['total']
            solicitud.save()
            
            Estimacion.objects.create(
                solicitud=solicitud,
                precio_calculado=estimacion['total'],
                desglose=estimacion.get('desglose', {}),
                es_referencial=True
            )
            
            del request.session['req_id']
            del request.session['estimacion']
            
            messages.success(request, f'Solicitud {solicitud.numero} creada!')
            return redirect('ver_solicitud', id=solicitud.id)
    else:
        form = SolicitudCreacionForm()
    
    return render(request, 'plataforma/solicitudes/crear_paso2.html', {
        'form': form,
        'estimacion': estimacion,
        'req': req
    })

@login_required
def solicitar_mejora(request):
    if request.method == 'POST':
        form = SolicitudMejoraForm(request.POST)
        if form.is_valid():
            solicitud = form.save(commit=False)
            solicitud.cliente = request.user
            solicitud.tipo = 'Mejora'
            solicitud.numero = GestorSolicitudes.generar_numero()
            solicitud.save()
            messages.success(request, f'Solicitud {solicitud.numero} creada!')
            return redirect('ver_solicitud', id=solicitud.id)
    else:
        form = SolicitudMejoraForm()
    
    return render(request, 'plataforma/solicitudes/mejora.html', {'form': form})

@login_required
def solicitar_soporte(request):
    if request.method == 'POST':
        form = SolicitudSoporteForm(request.POST)
        if form.is_valid():
            solicitud = form.save(commit=False)
            solicitud.cliente = request.user
            solicitud.tipo = 'Soporte'
            solicitud.numero = GestorSolicitudes.generar_numero()
            solicitud.prioridad = request.POST.get('prioridad', 'Media')
            solicitud.save()
            messages.success(request, f'Solicitud {solicitud.numero} creada!')
            return redirect('ver_solicitud', id=solicitud.id)
    else:
        form = SolicitudSoporteForm()
    
    return render(request, 'plataforma/solicitudes/soporte.html', {'form': form})

@login_required
def ver_solicitud(request, id):
    solicitud = get_object_or_404(Solicitud, id=id)
    
    if request.user != solicitud.cliente and not request.user.is_staff:
        messages.error(request, 'No tienes permiso.')
        return redirect('inicio')
    
    historial = solicitud.historial_cambios.all()
    
    context = {
        'solicitud': solicitud,
        'historial': historial,
    }
    return render(request, 'plataforma/solicitudes/ver.html', context)

@login_required
def mis_solicitudes(request):
    solicitudes = Solicitud.objects.filter(cliente=request.user).order_by('-fecha_solicitud')
    
    context = {
        'solicitudes': solicitudes,
    }
    return render(request, 'plataforma/mis_solicitudes.html', context)

@login_required
def chat_asistente(request):
    mensajes = MensajeChat.objects.filter(usuario=request.user).order_by('fecha')
    
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        form = MensajeChatForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            msg.usuario = request.user
            msg.es_asistente = False
            msg.save()
            
            respuesta = AsistenteIA.procesar_pregunta(msg.contenido)
            
            msg_ia = MensajeChat.objects.create(
                usuario=request.user,
                contenido=respuesta,
                es_asistente=True
            )
            
            return JsonResponse({
                'success': True,
                'respuesta': respuesta,
                'hora': msg_ia.fecha.strftime('%H:%M')
            })
    else:
        form = MensajeChatForm()
    
    return render(request, 'plataforma/chat.html', {
        'form': form,
        'mensajes': mensajes
    })

@login_required
def panel_admin(request):
    if not request.user.is_staff:
        messages.error(request, 'Acceso denegado.')
        return redirect('inicio')
    
    solicitudes = Solicitud.objects.all().order_by('-fecha_solicitud')
    total_solicitudes = solicitudes.count()
    
    context = {
        'solicitudes': solicitudes,
        'total_solicitudes': total_solicitudes,
        'solicitudes_recibidas': solicitudes.filter(estado_actual='Recibida').count(),
    }
    return render(request, 'plataforma/admin/panel.html', context)

@login_required
def admin_cambiar_estado(request, id):
    if not request.user.is_staff:
        return JsonResponse({'error': 'Acceso denegado'}, status=403)
    
    solicitud = get_object_or_404(Solicitud, id=id)
    
    if request.method == 'POST':
        nuevo_estado = request.POST.get('estado')
        comentario = request.POST.get('comentario', '')
        
        GestorSolicitudes.cambiar_estado(solicitud, nuevo_estado, comentario, request.user)
        messages.success(request, f'Solicitud actualizada a {nuevo_estado}')
    
    return redirect('ver_solicitud', id=id)
