from django.contrib import admin
from .models import (
    Categoria, Servicio, PerfilCliente, RequerimientoWeb,
    Solicitud, HistorialSolicitud, Estimacion, MensajeChat
)

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'orden', 'icono']
    ordering = ['orden']

@admin.register(Servicio)
class ServicioAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'tipo', 'categoria', 'precio_base', 'activo']
    list_filter = ['tipo', 'activo', 'categoria']
    search_fields = ['nombre', 'descripcion']

@admin.register(PerfilCliente)
class PerfilClienteAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'empresa', 'ciudad', 'fecha_registro']
    search_fields = ['usuario__email', 'empresa']

@admin.register(RequerimientoWeb)
class RequerimientoWebAdmin(admin.ModelAdmin):
    list_display = ['tipo_sitio', 'complejidad', 'num_paginas']
    list_filter = ['complejidad', 'tipo_sitio']

@admin.register(Solicitud)
class SolicitudAdmin(admin.ModelAdmin):
    list_display = ['numero', 'cliente', 'tipo', 'estado_actual', 'prioridad', 'fecha_solicitud']
    list_filter = ['tipo', 'estado_actual', 'prioridad', 'fecha_solicitud']
    search_fields = ['numero', 'cliente__email', 'titulo']
    readonly_fields = ['numero', 'fecha_solicitud']

@admin.register(HistorialSolicitud)
class HistorialSolicitudAdmin(admin.ModelAdmin):
    list_display = ['solicitud', 'estado_anterior', 'estado_nuevo', 'fecha']
    list_filter = ['fecha']
    readonly_fields = ['solicitud', 'estado_anterior', 'estado_nuevo', 'fecha']

@admin.register(Estimacion)
class EstimacionAdmin(admin.ModelAdmin):
    list_display = ['solicitud', 'precio_calculado', 'es_referencial', 'fecha_calculo']
    readonly_fields = ['solicitud', 'fecha_calculo']

@admin.register(MensajeChat)
class MensajeChatAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'es_asistente', 'fecha']
    list_filter = ['es_asistente', 'fecha']
    readonly_fields = ['fecha']
