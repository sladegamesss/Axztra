from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# ═════════════════════════════════════════════════════════════
# CATEGORÍAS Y SERVICIOS
# ═════════════════════════════════════════════════════════════

class Categoria(models.Model):
    nombre = models.CharField(max_length=120, unique=True)
    descripcion = models.TextField(blank=True)
    icono = models.CharField(max_length=50, default='📦')
    orden = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['orden', 'nombre']
        verbose_name_plural = "Categorías"
    
    def __str__(self):
        return self.nombre


class Servicio(models.Model):
    TIPOS = [
        ('Creacion', 'Creación de página web'),
        ('Mejora', 'Mejora de página existente'),
        ('Soporte', 'Soporte técnico'),
        ('Mantenimiento', 'Mantenimiento'),
    ]
    
    nombre = models.CharField(max_length=120)
    descripcion = models.TextField()
    tipo = models.CharField(max_length=20, choices=TIPOS)
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True, blank=True)
    precio_base = models.PositiveIntegerField(default=0)
    imagen_url = models.URLField(blank=True)
    activo = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['tipo', 'nombre']
    
    def __str__(self):
        return f"{self.nombre} ({self.get_tipo_display()})"


# ═════════════════════════════════════════════════════════════
# PERFIL DE CLIENTE
# ═════════════════════════════════════════════════════════════

class PerfilCliente(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, related_name='perfil_cliente')
    empresa = models.CharField(max_length=200, blank=True)
    telefono = models.CharField(max_length=20, blank=True)
    rut = models.CharField(max_length=20, blank=True)
    ciudad = models.CharField(max_length=100, blank=True)
    fecha_registro = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Perfil - {self.usuario.get_full_name() or self.usuario.username}"


# ═════════════════════════════════════════════════════════════
# REQUERIMIENTOS WEB
# ═════════════════════════════════════════════════════════════

class RequerimientoWeb(models.Model):
    TIPOS_SITIO = [
        ('Blog', 'Blog/Portafolio'),
        ('Ecommerce', 'Tienda Online'),
        ('Corporativo', 'Sitio Corporativo'),
        ('Servicio', 'Sitio de Servicios'),
        ('Otro', 'Otro'),
    ]
    
    COMPLEJIDAD = [
        ('Basica', 'Básica'),
        ('Media', 'Media'),
        ('Alta', 'Alta'),
    ]
    
    tipo_sitio = models.CharField(max_length=20, choices=TIPOS_SITIO)
    num_paginas = models.PositiveIntegerField(default=5)
    complejidad = models.CharField(max_length=10, choices=COMPLEJIDAD, default='Media')
    
    tiene_ecommerce = models.BooleanField(default=False)
    tiene_formulario = models.BooleanField(default=False)
    tiene_galeria = models.BooleanField(default=False)
    tiene_blog = models.BooleanField(default=False)
    tiene_login = models.BooleanField(default=False)
    tiene_integracion_pago = models.BooleanField(default=False)
    
    descripcion = models.TextField(blank=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    def calcular_estimacion(self):
        precios_base = {'Basica': 300000, 'Media': 600000, 'Alta': 1000000}
        precio = precios_base.get(self.complejidad, 600000)
        precio += (self.num_paginas - 1) * 50000
        
        extras = {
            'ecommerce': 300000 if self.tiene_ecommerce else 0,
            'formulario': 100000 if self.tiene_formulario else 0,
            'galeria': 80000 if self.tiene_galeria else 0,
            'blog': 150000 if self.tiene_blog else 0,
            'login': 100000 if self.tiene_login else 0,
            'pago': 200000 if self.tiene_integracion_pago else 0,
        }
        
        return {'total': precio + sum(extras.values()), 'desglose': extras}
    
    def __str__(self):
        return f"{self.get_tipo_sitio_display()} - {self.get_complejidad_display()}"


# ═════════════════════════════════════════════════════════════
# SOLICITUDES
# ═════════════════════════════════════════════════════════════

class Solicitud(models.Model):
    TIPOS = [
        ('Creacion', 'Creación'),
        ('Mejora', 'Mejora'),
        ('Soporte', 'Soporte'),
        ('Mantenimiento', 'Mantenimiento'),
    ]
    
    ESTADOS = [
        ('Recibida', 'Recibida'),
        ('Revision', 'En Revisión'),
        ('Cotizacion', 'Cotización'),
        ('Aprobada', 'Aprobada'),
        ('Desarrollo', 'En Desarrollo'),
        ('Entrega', 'Lista para Entregar'),
        ('Completada', 'Completada'),
        ('Cancelada', 'Cancelada'),
    ]
    
    numero = models.CharField(max_length=20, unique=True)
    cliente = models.ForeignKey(User, on_delete=models.CASCADE, related_name='solicitudes_plataforma')
    tipo = models.CharField(max_length=20, choices=TIPOS)
    servicio = models.ForeignKey(Servicio, on_delete=models.SET_NULL, null=True, blank=True)
    
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField()
    requerimientos = models.ForeignKey(RequerimientoWeb, on_delete=models.SET_NULL, null=True, blank=True)
    
    estimacion_precio = models.PositiveIntegerField(null=True, blank=True)
    precio_final = models.PositiveIntegerField(null=True, blank=True)
    
    estado_actual = models.CharField(max_length=20, choices=ESTADOS, default='Recibida')
    prioridad = models.CharField(max_length=10, choices=[('Baja', 'Baja'), ('Media', 'Media'), ('Alta', 'Alta')], default='Media')
    
    fecha_solicitud = models.DateTimeField(auto_now_add=True)
    fecha_entrega_estimada = models.DateTimeField(null=True, blank=True)
    
    activa = models.BooleanField(default=True)
    notas_internas = models.TextField(blank=True)
    
    class Meta:
        ordering = ['-fecha_solicitud']
    
    def __str__(self):
        return f"{self.numero} - {self.titulo}"


class HistorialSolicitud(models.Model):
    solicitud = models.ForeignKey(Solicitud, on_delete=models.CASCADE, related_name='historial_cambios')
    estado_anterior = models.CharField(max_length=20)
    estado_nuevo = models.CharField(max_length=20)
    comentario = models.TextField(blank=True)
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-fecha']
    
    def __str__(self):
        return f"{self.solicitud.numero}: {self.estado_anterior} → {self.estado_nuevo}"


# ═════════════════════════════════════════════════════════════
# ESTIMACIONES
# ═════════════════════════════════════════════════════════════

class Estimacion(models.Model):
    solicitud = models.OneToOneField(Solicitud, on_delete=models.CASCADE, related_name='estimacion_plataforma')
    precio_calculado = models.PositiveIntegerField()
    desglose = models.JSONField(default=dict, blank=True)
    notas = models.TextField(blank=True)
    es_referencial = models.BooleanField(default=True)
    fecha_calculo = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"${self.precio_calculado:,} - {self.solicitud.numero}"


# ═════════════════════════════════════════════════════════════
# CHAT IA
# ═════════════════════════════════════════════════════════════

class MensajeChat(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    contenido = models.TextField()
    es_asistente = models.BooleanField(default=False)
    fecha = models.DateTimeField(auto_now_add=True)
    sesion_id = models.CharField(max_length=100, blank=True)
    
    class Meta:
        ordering = ['fecha']
    
    def __str__(self):
        return f"{'IA' if self.es_asistente else 'Cliente'}: {self.contenido[:50]}"
