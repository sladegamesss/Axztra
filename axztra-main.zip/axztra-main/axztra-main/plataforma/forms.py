from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import RequerimientoWeb, Solicitud, MensajeChat, PerfilCliente

class RegistroForm(UserCreationForm):
    first_name = forms.CharField(label='Nombre completo', max_length=120, required=True)
    email = forms.EmailField(label='Correo electrónico', required=True)
    
    class Meta:
        model = User
        fields = ['first_name', 'username', 'email', 'password1', 'password2']
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Este correo ya está registrado.')
        return email

class LoginForm(forms.Form):
    email = forms.EmailField(label='Correo electrónico')
    password = forms.CharField(widget=forms.PasswordInput, label='Contraseña')

class RequerimientoWebForm(forms.ModelForm):
    class Meta:
        model = RequerimientoWeb
        fields = ['tipo_sitio', 'num_paginas', 'complejidad', 'tiene_ecommerce', 
                  'tiene_formulario', 'tiene_galeria', 'tiene_blog', 'tiene_login', 
                  'tiene_integracion_pago', 'descripcion']
        labels = {
            'tipo_sitio': '¿Qué tipo de sitio necesitas?',
            'num_paginas': 'Cantidad de páginas',
            'complejidad': 'Complejidad del proyecto',
            'tiene_ecommerce': '¿Tienda online?',
            'tiene_formulario': '¿Formularios de contacto?',
            'tiene_galeria': '¿Galería de imágenes?',
            'tiene_blog': '¿Blog/noticias?',
            'tiene_login': '¿Sistema de login?',
            'tiene_integracion_pago': '¿Pasarela de pagos?',
            'descripcion': 'Describe tu proyecto...',
        }

class SolicitudCreacionForm(forms.ModelForm):
    class Meta:
        model = Solicitud
        fields = ['titulo', 'descripcion', 'fecha_entrega_estimada']
        labels = {
            'titulo': 'Nombre del proyecto',
            'descripcion': 'Descripción detallada',
            'fecha_entrega_estimada': 'Fecha estimada de entrega',
        }

class SolicitudMejoraForm(forms.ModelForm):
    class Meta:
        model = Solicitud
        fields = ['titulo', 'descripcion']

class SolicitudSoporteForm(forms.ModelForm):
    class Meta:
        model = Solicitud
        fields = ['titulo', 'descripcion']

class MensajeChatForm(forms.ModelForm):
    class Meta:
        model = MensajeChat
        fields = ['contenido']
        labels = {'contenido': ''}
        widgets = {
            'contenido': forms.TextInput(attrs={'placeholder': 'Escribe tu pregunta...', 'class': 'form-control'})
        }

class PerfilClienteForm(forms.ModelForm):
    class Meta:
        model = PerfilCliente
        fields = ['empresa', 'telefono', 'rut', 'ciudad']
