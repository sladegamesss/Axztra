document.documentElement.classList.add('con-js');
