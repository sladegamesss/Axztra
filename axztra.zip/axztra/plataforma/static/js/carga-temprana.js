// Se carga antes que el resto: marca que JavaScript está activo para ajustar algunos estilos.
document.documentElement.classList.add('con-js');
