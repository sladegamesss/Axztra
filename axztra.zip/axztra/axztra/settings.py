import importlib.util
import os
import sys
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlparse

from django.contrib.messages import constants as message_constants
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent


def entorno_bool(nombre, defecto):
    valor = os.environ.get(nombre)
    if valor is None:
        return defecto
    return valor.strip().lower() in ('1', 'true', 'si', 'yes', 'on')


def entorno_lista(nombre, defecto):
    valor = os.environ.get(nombre)
    if not valor:
        return defecto
    return [item.strip() for item in valor.split(',') if item.strip()]


def entorno_int(nombre, defecto):
    try:
        return int(os.environ.get(nombre, defecto))
    except (TypeError, ValueError):
        return defecto


def base_de_datos_desde_url(url):
    partes = urlparse(url)
    if partes.scheme == 'sqlite':
        ruta = unquote(partes.path)
        nombre = Path(ruta[1:]) if ruta.startswith('//') else BASE_DIR / (ruta.lstrip('/') or 'db.sqlite3')
        return {'ENGINE': 'django.db.backends.sqlite3', 'NAME': nombre}
    if partes.scheme in ('postgres', 'postgresql', 'pgsql'):
        configuracion = {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': unquote(partes.path.lstrip('/')),
            'USER': unquote(partes.username or ''),
            'PASSWORD': unquote(partes.password or ''),
            'HOST': partes.hostname or 'localhost',
            'PORT': str(partes.port or 5432),
        }
        opciones = dict(parse_qsl(partes.query))
        if opciones:
            configuracion['OPTIONS'] = opciones
        return configuracion
    raise ValueError(f'Motor de base de datos no soportado: {partes.scheme}')


def paquete_instalado(nombre):
    return importlib.util.find_spec(nombre) is not None


SECRET_KEY = os.environ.get(
    'DJANGO_SECRET_KEY',
    'axztra-desarrollo-local-reemplazar-en-produccion-7f3c9a1e5b',
)

DEBUG = entorno_bool('DJANGO_DEBUG', True)

if not DEBUG and SECRET_KEY.startswith('axztra-desarrollo-local'):
    raise ImproperlyConfigured('Define la variable de entorno DJANGO_SECRET_KEY antes de ejecutar con DJANGO_DEBUG=0.')

ALLOWED_HOSTS = entorno_lista('DJANGO_ALLOWED_HOSTS', ['localhost', '127.0.0.1', '[::1]'])
CSRF_TRUSTED_ORIGINS = entorno_lista('DJANGO_CSRF_TRUSTED_ORIGINS', [])

USAR_WHITENOISE = paquete_instalado('whitenoise')

INSTALLED_APPS = [
    'plataforma.apps.AxztraAdminConfig',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    'django.contrib.sitemaps',
    'plataforma.apps.PlataformaConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    *(['whitenoise.middleware.WhiteNoiseMiddleware'] if USAR_WHITENOISE else []),
    'plataforma.seguridad.CabecerasSeguridadMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'axztra.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'plataforma.context_processors.datos_empresa',
            ],
        },
    },
]

WSGI_APPLICATION = 'axztra.wsgi.application'
ASGI_APPLICATION = 'axztra.asgi.application'

if os.environ.get('DATABASE_URL'):
    DATABASES = {'default': base_de_datos_desde_url(os.environ['DATABASE_URL'])}
elif os.environ.get('POSTGRES_DB'):
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('POSTGRES_DB'),
            'USER': os.environ.get('POSTGRES_USER', 'postgres'),
            'PASSWORD': os.environ.get('POSTGRES_PASSWORD', ''),
            'HOST': os.environ.get('POSTGRES_HOST', 'localhost'),
            'PORT': os.environ.get('POSTGRES_PORT', '5432'),
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
            'OPTIONS': {'timeout': 20},
        }
    }

if DATABASES['default']['ENGINE'] == 'django.db.backends.postgresql':
    DATABASES['default']['CONN_MAX_AGE'] = entorno_int('DJANGO_CONN_MAX_AGE', 60)
    DATABASES['default']['CONN_HEALTH_CHECKS'] = True

if os.environ.get('REDIS_URL'):
    CACHES = {
        'default': {
            'BACKEND': 'django.core.cache.backends.redis.RedisCache',
            'LOCATION': os.environ['REDIS_URL'],
            'TIMEOUT': 300,
            'KEY_PREFIX': 'axztra',
        }
    }
else:
    CACHES = {
        'default': {
            'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
            'LOCATION': 'axztra',
            'TIMEOUT': 300,
            'OPTIONS': {'MAX_ENTRIES': 5000},
        }
    }

SESSION_ENGINE = 'django.contrib.sessions.backends.cached_db'
SESSION_COOKIE_AGE = 60 * 60 * 8
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = 'Lax'

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'es-cl'
TIME_ZONE = 'America/Santiago'
USE_I18N = True
USE_TZ = True
USE_THOUSAND_SEPARATOR = False

STATIC_URL = '/static/'
STATIC_ROOT = Path(os.environ.get('DJANGO_STATIC_ROOT', BASE_DIR / 'staticfiles'))
MEDIA_URL = '/media/'
MEDIA_ROOT = Path(os.environ.get('DJANGO_MEDIA_ROOT', BASE_DIR / 'media'))

USAR_MANIFIESTO = entorno_bool('DJANGO_STATIC_MANIFEST', not DEBUG)
if USAR_MANIFIESTO and USAR_WHITENOISE:
    MOTOR_ESTATICOS = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
elif USAR_MANIFIESTO:
    MOTOR_ESTATICOS = 'django.contrib.staticfiles.storage.ManifestStaticFilesStorage'
else:
    MOTOR_ESTATICOS = 'django.contrib.staticfiles.storage.StaticFilesStorage'

STORAGES = {
    'default': {'BACKEND': 'django.core.files.storage.FileSystemStorage'},
    'staticfiles': {'BACKEND': MOTOR_ESTATICOS},
}

FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 12 * 1024 * 1024
FILE_UPLOAD_PERMISSIONS = 0o640

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'inicio'
LOGOUT_REDIRECT_URL = 'inicio'
PASSWORD_RESET_TIMEOUT = 60 * 60 * 24

MESSAGE_TAGS = {
    message_constants.ERROR: 'danger',
}

EMAIL_BACKEND = os.environ.get('DJANGO_EMAIL_BACKEND') or (
    'django.core.mail.backends.smtp.EmailBackend' if os.environ.get('EMAIL_HOST') else 'django.core.mail.backends.console.EmailBackend'
)
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'localhost')
EMAIL_PORT = entorno_int('EMAIL_PORT', 587)
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = entorno_bool('EMAIL_USE_TLS', True)
EMAIL_TIMEOUT = 15
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'AXZTRA <notificaciones@axztra.cl>')
SERVER_EMAIL = DEFAULT_FROM_EMAIL

ADMIN_URL = os.environ.get('DJANGO_ADMIN_URL', 'admin/').strip('/') + '/'

AXZTRA = {
    'NOMBRE': 'AXZTRA',
    'URL_SITIO': os.environ.get('AXZTRA_URL_SITIO', 'http://127.0.0.1:8000').rstrip('/'),
    'CORREO_CONTACTO': os.environ.get('AXZTRA_CORREO', 'contacto@axztra.cl'),
    'CORREO_ADMINISTRACION': os.environ.get('AXZTRA_CORREO_ADMIN', 'contacto@axztra.cl'),
    'WHATSAPP': os.environ.get('AXZTRA_WHATSAPP', '56912345678'),
    'WHATSAPP_VISIBLE': os.environ.get('AXZTRA_WHATSAPP_VISIBLE', '+56 9 1234 5678'),
    'UBICACION': 'Hualpén, Región del Biobío, Chile',
    'HORARIO': 'Lunes a viernes, de 9:00 a 18:00 horas',
    'CODIGO_VERIFICACION_MINUTOS': 10,
    'CODIGO_VERIFICACION_INTENTOS': 5,
    'IVA': 19,
    'SLA_HORAS': {'urgente': 4, 'alta': 24, 'media': 48, 'baja': 72},
    'ADJUNTOS_MAXIMO_MB': 10,
    'ADJUNTOS_EXTENSIONES': ['pdf', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'docx', 'xlsx', 'pptx', 'txt', 'zip'],
    'CORREO_ASINCRONO': entorno_bool('AXZTRA_CORREO_ASINCRONO', True),
    'CONFIAR_PROXY': entorno_bool('AXZTRA_CONFIAR_PROXY', False),
    'LIMITES_ACTIVOS': entorno_bool('AXZTRA_LIMITES_ACTIVOS', True),
    'BOTPRESS_SCRIPTS': entorno_lista('AXZTRA_BOTPRESS_SCRIPTS', []),
}

EN_PRUEBAS = len(sys.argv) > 1 and sys.argv[1] == 'test'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'simple': {'format': '[{asctime}] {levelname} {name}: {message}', 'style': '{', 'datefmt': '%d/%m/%Y %H:%M:%S'},
    },
    'handlers': {
        'consola': {'class': 'logging.StreamHandler', 'formatter': 'simple'},
    },
    'loggers': {
        'plataforma': {'handlers': ['consola'], 'level': 'CRITICAL' if EN_PRUEBAS else os.environ.get('AXZTRA_LOG_NIVEL', 'INFO'), 'propagate': False},
        'django.request': {'handlers': ['consola'], 'level': 'CRITICAL' if EN_PRUEBAS else 'ERROR', 'propagate': False},
        'django.security': {'handlers': ['consola'], 'level': 'WARNING', 'propagate': False},
    },
}

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'
X_FRAME_OPTIONS = 'DENY'

if not DEBUG:
    SESSION_COOKIE_SECURE = entorno_bool('DJANGO_COOKIES_SEGURAS', True)
    CSRF_COOKIE_SECURE = entorno_bool('DJANGO_COOKIES_SEGURAS', True)
    SECURE_SSL_REDIRECT = entorno_bool('DJANGO_SSL_REDIRECT', False)
    SECURE_HSTS_SECONDS = entorno_int('DJANGO_HSTS_SEGUNDOS', 0)
    SECURE_HSTS_INCLUDE_SUBDOMAINS = SECURE_HSTS_SECONDS > 0
    SECURE_HSTS_PRELOAD = False
    if entorno_bool('DJANGO_DETRAS_DE_PROXY', False):
        SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
